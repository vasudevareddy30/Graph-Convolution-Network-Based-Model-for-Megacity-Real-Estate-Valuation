from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from User.models import UserPrediction
from django.core.paginator import Paginator

def adminhome(request):
    users = User.objects.filter(is_staff=False, is_superuser=False) 
    return render(request, "Admin/adminhome.html", {"users": users})

def admin_update_userstatus(request, user_id):
    try:
        user = User.objects.get(id=user_id)
        
        # Toggle the is_active status
        user.is_active = not user.is_active
        user.save()

        # Display message based on the action
        if user.is_active:
            messages.success(request, f"User {user.username} has been activated.")
        else:
            messages.success(request, f"User {user.username} has been deactivated.")
        
        return redirect('adminhome')  # Redirect back to the admin home page
    except User.DoesNotExist:
        messages.error(request, "User not found.")
        return redirect('adminhome')
    
def adminuserpredictions(request):
    predictions_list = UserPrediction.objects.order_by('-timestamp')
    paginator = Paginator(predictions_list, 10)  

    page_number = request.GET.get('page')
    predictions = paginator.get_page(page_number)

    return render(request, 'Admin/adminuserpredictions.html', {'predictions': predictions})